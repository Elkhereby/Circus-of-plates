/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import eg.edu.alexu.csd.oop.game.GameObject;
import java.awt.image.BufferedImage;

/**
 *
 * @author elsam
 */
public class Clown extends ImageObject {

    public Clown(int posX, int posY, String path) {
        super(posX, posY, path,true);
    }
}
