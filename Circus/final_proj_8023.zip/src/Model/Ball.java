/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author elsam
 */
public class Ball extends Shape {



    public Ball(int posX, int posY, String path, int type) {
        super(posX, posY, path, type);

    }



  
}
