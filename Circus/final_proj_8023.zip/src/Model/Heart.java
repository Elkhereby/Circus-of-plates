package Model;

import Model.ImageObject;

public class Heart extends ImageObject{

    public Heart(int posX, int posY, String path) {
        super(posX, posY, path,false);
    }

}
