/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author elsam
 */
public class Background extends ImageObject {

    public Background(int posX, int posY, String path) {
        super(posX, posY, path, false);
    }

}
