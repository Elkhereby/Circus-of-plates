package Model;

public class ControllableBall extends Shape {

    int y;
    private int lefthand = 0;
    private Clown clown;

    public ControllableBall(int posX, int posY, String path, int type, Clown clown) {
        super(posX, posY, path, type);
        this.clown = clown;
    }

    public int isLefthand() {
        return lefthand;
    }

    public void setLefthand(int lefthand) {
        this.lefthand = lefthand;
    }

    @Override
    public void setY(int mY) {
    }

    @Override
    public void setX(int mX) {
        if (lefthand == 1) {
            super.setX(clown.getX() - 2);
        } else if (lefthand == 2) {
            super.setX(clown.getX() + 107);
        } else {
            super.setX(mX);
        }
    }
}
